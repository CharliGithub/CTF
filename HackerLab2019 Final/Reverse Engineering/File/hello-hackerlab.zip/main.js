
chrome.app.runtime.onLaunched.addListener(function() {
  // Center window on screen.
  var screenWidth = screen.availWidth;
  var screenHeight = screen.availHeight;
  var width = 500;
  var height = 300;
  //console.log("43,54,46,5f,59,6f,75,57,69,6e,54,68,65,43,68,72,6f,6d,65,41,70,70,52,65,76,65,72,73,65,42,65,67,69,6e,6e,65,72,42,61,64,67,65");

  chrome.app.window.create('index.html', {
    id: "helloWorldID",
    outerBounds: {
      width: width,
      height: height,
      left: Math.round((screenWidth-width)/2),
      top: Math.round((screenHeight-height)/2)
    }
  });
});
